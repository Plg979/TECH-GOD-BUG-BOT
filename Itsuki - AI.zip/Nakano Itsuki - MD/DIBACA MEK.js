/* Credits Shyo 

𝗯𝗮𝗰𝗮 𝗶𝗻𝗶 𝘀𝗲𝗯𝗲𝗹𝘂𝗺 𝗺𝗮𝗸𝗮𝗶
[ Creator Real ] ShyoID (intinya shyo 🤓) 
[ Partner ] ShyoCannn ( Cantika si imut
[ BASE ] MieChan By Shyo
[ Type Script ] Plugins Esm × Case 
[ Fix ] Script Raiden By Shyo
[ Update + Fix All ] Script Itsuki By Shyo
[ Baileys ] Kyami titit
[ Support ] All Pengguna script ini

Link Script : 
https://whatsapp.com/channel/0029VavBc6uHAdNdbgCgOK0k

Link Script 2: 
https://chat.whatsapp.com/IFK1YCPjygj3PdJ5Z6k9h9

Jangan Delete Credits gw 

Buy Script MieChanMD 90% All Work? Chat Shyo 

Whatsapp : https://wa.me//6282176642989
Tele : t.me/@Shyoaja 
Youtube : ShyoCannn
Tiktok : shyonotsepuh

*/

