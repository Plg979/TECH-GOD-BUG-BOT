/*============== MOHON DIBACA ==============

BASE SCRIPT : MIECHAN

DI FIX ULANG OLEH : FALLZX INFINITY


BUY BASE ORI MICHAN ? CHAT DINOMOR BAWAH INI
NO : 6282118796446
*/
import { watchFile, unwatchFile } from 'fs'
import chalk from 'chalk'
import { fileURLToPath } from 'url'

global.config = {
    /*============== INFO LINK ==============*/
    instagram: 'https://www.instagram.com/ypisajalah_/',
    github: 'https://github.com/shyo',
    group: 'https://chat.whatsapp.com/IFK1YCPjygj3PdJ5Z6k9h9',
    website: 'https://nekopoi.care',
    saluran: 'https://whatsapp.com/channel/0029VavBc6uHAdNdbgCgOK0k',

    /*============== PAYMENT ==============*/
    dana: '082176642989',
    ovo: '_',
    gopay: '083121128238',
    pulsa: '082176642989',

    /*============== STAFF ==============*/
    owner: [
        ['082176642989', 'ShyoID', true]

    ],

    /*============= PAIRING =============*/
    pairingNumber: "6285187387839",
    pairingAuth: true,

    /*============== API ==============*/
    APIs: {
        lol: 'https://api.lolhuman.xyz',
        rose: 'https://api.itsrose.rest',
        xzn: 'https://skizoasia.xyz',
        betabotz : 'https://api.betabotz.eu.org',
    },

    APIKeys: {
        'https://api.lolhuman.xyz': 'ZenOfficial',
        'https://api.itsrose.rest': 'Rk-f5d4b183e7dd3dd0a44653678ba5107c',
        'https://skizoasia.xyz': 'zenOfficial',
        'https://api.betabotz.eu.org': 'ZenOfficial',
    },

    /*============== TEXT ==============*/
    watermark: 'Arona-MD',
    author: 'BlueArchive',
    loading: 'Mohon ditunggu...',
    errorMsg: 'Error :)',

    stickpack: 'Made With',
    stickauth: 'ARONO - AI Sewa? Chat : 085813708397',

    digi: {
        username: "",
        apikey: ""
    },

    OK: {
        ID: "_",
        Pin: "_",
        Pass: "_",        
        Apikey: "_"
    },
    
    taxRate: 0.05,
    taxMax: 2000
}

global.loading = (m, conn, back = false) => {
    if (!back) {
        return conn.sendReact(m.chat, "🕒", m.key)
    } else {
        return conn.sendReact(m.chat, "", m.key)
    }
}

/*============== EMOJI ==============*/
global.rpg = {
    emoticon(string) {
        string = string.toLowerCase()
        let emot = {
            level: '📊',
            limit: '🎫',
            health: '❤️',
            exp: '✨',
            atm: '💳',
            money: '💰',
            bank: '🏦',
            potion: '🥤',
            diamond: '💎',
            common: '📦',
            uncommon: '🛍️',
            mythic: '🎁',
            legendary: '🗃️',
            superior: '💼',
            pet: '🔖',
            trash: '🗑',
            armor: '🥼',
            sword: '⚔️',
            pickaxe: '⛏️',
            fishingrod: '🎣',
            wood: '🪵',
            rock: '🪨',
            string: '🕸️',
            horse: '🐴',
            cat: '🐱',
            dog: '🐶',
            fox: '🦊',
            robo: '🤖',
            dragon: '🐉',
            lion: '🦁',
            rhinoceros: '🦏',
            centaur: '🦄',
            kyubi: '🦊',
            griffin: '🦅',
            phonix: '🔥',
            wolf: '🐺',
            petfood: '🍖',
            iron: '⛓️',
            gold: '🪙',
            emerald: '❇️',
            upgrader: '🧰',
            bibitanggur: '🌱',
            bibitjeruk: '🌿',
            bibitapel: '☘️',
            bibitmangga: '🍀',
            bibitpisang: '🌴',
            anggur: '🍇',
            jeruk: '🍊',
            apel: '🍎',
            mangga: '🥭',
            pisang: '🍌',
            botol: '🍾',
            kardus: '📦',
            kaleng: '🏮',
            plastik: '📜',
            gelas: '🧋',
            chip: '♋',
            umpan: '🪱',
            skata: '🧩',
            bitcoin: '☸️',
            polygon: '☪️',
            dogecoin: '☯️',
            etherium: '⚛️',
            solana: '✡️',
            memecoin: '☮️',
            donasi: '💸',
            ammn: '⚖️',
            bbca: '💵',
            bbni: '💴',
            cuan: '🧱',
            bbri: '💶',
            msti: '📡',
            steak: '🥩',
            ayam_goreng: '🍗',
            ribs: '🍖',
            roti: '🍞',
            udang_goreng: '🍤',
            bacon: '🥓',
            gandum: '🌾',
            minyak: '🥃',
            garam: '🧂',
            babi: '🐖',
            ayam: '🐓',
            sapi: '🐮',
            udang: '🦐'
        }
        if (typeof emot[string] !== 'undefined') {
            return emot[string]
        } else {
            return ''
        }
    }
}

//------ JANGAN DIUBAH -----
let file = fileURLToPath(import.meta.url)
watchFile(file, () => {
    unwatchFile(file)
    console.log(chalk.redBright("Update 'config.js'"))
    import(`${file}?update=${Date.now()}`)
})
