async function getAnyaResponse(text, apiKey) {
    try {
        const response = await fetch(`https://api.crafters.biz.id/ai/anya?text=${encodeURIComponent(text)}`, {
            headers: {
                'Authorization': `Bearer ${apiKey}`
            }
        });
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();
        return data;
    } catch (error) {
        console.error("Error fetching Anya AI response:", error);
        return { error: "Failed to fetch response" };
    }
}

// Contoh penggunaan
const apiKey = "https://api.crafters.biz.id/ai/anya?text=$";
getAnyaResponse("Halo, apa kabar?", apiKey).then(response => console.log(response));

handler.help = ["anya"];
handler.tags = ["ai"];
handler.command = ["anya"];
export default handler