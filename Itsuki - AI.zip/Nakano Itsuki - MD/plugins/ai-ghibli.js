import axios from 'axios';
import FormData from 'form-data';
const ghibliStyle = {
  api: {
    base: "https://ghiblistyleimagegenerator.cc/api",
    endpoints: {
      generate: "/generate-ghibli"
    }
  },
  headers: {
    'authority': 'ghiblistyleimagegenerator.cc',
    'origin': 'https://ghiblistyleimagegenerator.cc',
    'referer': 'https://ghiblistyleimagegenerator.cc/',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
  }
};
const handler = async (m, {
  conn,
  usedPrefix,
  command
}) => {
  try {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';
    if (!mime) throw 'Takda gambar, reply gambar/beri caption digambar';
    if (!mime.startsWith('image')) throw 'hanya gambar bre!';
    
    const media = await q.download();
    const base64Image = media.toString('base64');
    await m.reply('⏳ proses bre..');
    const response = await axios.post(
      `${ghibliStyle.api.base}${ghibliStyle.api.endpoints.generate}`, {
        image: base64Image
      }, {
        headers: ghibliStyle.headers
      }
    );
    
    if (!response.data.success) throw 'gagal buay gambar';
    const ghibliImageUrl = response.data.ghibliImage;
   //uploaded 
    const form = new FormData();
    form.append('reqtype', 'fileupload');
    form.append('userhash', '');
    form.append('fileToUpload', Buffer.from(media), 'ghibli.jpg');
    const upres = await axios.post('https://catbox.moe/user/api.php', form, {
      headers: form.getHeaders()
    });
    const upUrl = upres.data.trim();
    await conn.sendMessage(m.chat, {
      image: {
        url: ghibliImageUrl
      },
      caption: `🎨 *Ghibli Style Image Generated*`,
      mentions: [m.sender]
    }, {
      quoted: m
    });
    
  } catch (error) {
    console.error('Error:', error);
    await m.reply(`Error: ${error.message || 'gagal proses gmbr'}`);
  }
};

handler.help = ['ghibli'];
handler.tags = ['ai'];
handler.command = /^(ghibli|ghiblistyle)$/i;
handler.limit = true;
export default handler;