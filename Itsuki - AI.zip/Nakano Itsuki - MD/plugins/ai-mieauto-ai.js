import axios from "axios";
 
let handler = async (m, { conn, text }) => {
  if (!text) throw `*• Example:* .aronaai *[on/off]*`;
 
  if (text === "on") {
    conn.autoai = true;
    m.reply("[ ✓ ] Arona AutoAI berhasil diaktifkan.");
  } else if (text === "off") {
    conn.autoai = false;
    m.reply("[ ✓ ] Arona AutoAI berhasil dimatikan.");
  } else {
    m.reply("Gunakan format: *.aronaai on* atau *.aronaai off*");
  }
};
 
handler.before = async (m, { conn }) => {
  if (!conn.autoai) return;
  if (!m.text || m.fromMe || m.isCommand) return;
 
  const mentioned = m.mentionedJid || [];
  const botNumber = conn.user.jid;
  const isTagBot = mentioned.includes(botNumber);
  const isReplyToBot = m.quoted && m.quoted.fromMe;
 
  if (!isTagBot && !isReplyToBot) return;
 
  try {
    const prompt = `Kamu adalah mie ai yang menjawab semua pertanyaan dengan bahasa Indonesia yang baku dan ramah`;
    const content = m.text;
 
    const res = await axios.get(`https://api.siputzx.my.id/api/ai/gpt3`, {
      params: {
        prompt,
        content
      }
    });
 
    console.log("[DEBUG RESPON AUTOAI]", res.data);
 
    let reply = "bingung mau jawab apa...";
 
    if (res.data?.data) {
      reply = res.data.data;
    }
 
    await conn.sendMessage(m.chat, {
      text: reply,
      contextInfo: {
        externalAdReply: {
          title: 'Auto Ai',
          body: 'Asisten Pribadi dari Shyo',
          thumbnailUrl: 'https://files.catbox.moe/3ou3o4.jpg',
          sourceUrl: 'https://whatsapp.com/channel/0029VavBc6uHAdNdbgCgOK0k',
          mediaType: 1,
          renderLargerThumbnail: false,
          showAdAttribution: true
        }
      }
    }, { quoted: m });
 
  } catch (e) {
    console.error("[ERROR AUTOAI]", e);
    m.reply("Yahhh lgi error kak");
  }
};
 
handler.command = ['aronaai'];
handler.tags = ['ai', 'premium'];
handler.help = ['aronaai'].map(cmd => `${cmd} *[on/off]*`);
handler.premium = true;
 
export default handler;