import fetch from 'node-fetch';

const handler = async (m, { conn, text }) => {
  if (!text) {
    return conn.reply(m.chat, 'Silakan masukkan pesan untuk chat dengan Mistral AI.\nContoh: .mistralai Halo, apa kabar?', m);
  }

  const api = `https://api.crafters.biz.id/ai/mistral?text=${encodeURIComponent(text)}`;

  try {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });

    const response = await fetch(api);
    if (!response.ok) throw new Error('Gagal mengambil respon dari API');

    const json = await response.json();
    if (!json.status || !json.result) {
      throw new Error('Respon tidak valid dari API');
    }

    const replyText = json.result;
    await conn.reply(m.chat, replyText, m);

    await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
  } catch (error) {
    console.error(error);
    conn.reply(m.chat, 'Terjadi kesalahan saat mengambil respon dari Mistral AI.', m);
    await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
  }
};

handler.help = ['mistral <pesan>'];
handler.tags = ['ai'];
handler.command = /^(mistral)$/i;

export default handler;