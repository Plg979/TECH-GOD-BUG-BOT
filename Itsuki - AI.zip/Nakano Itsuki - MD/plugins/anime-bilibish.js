import axios from 'axios'

const handler = async (m, { conn, args, usedPrefix, command }) => {
  const query = args.join(' ')
  if (!query) {
    throw `[  !  ]Masukkan kata kunci!\n\n*Contoh:*\n${usedPrefix + command} overflow`
  }

  try {
    const { data } = await axios.get(`https://api.hiuraa.my.id/search/bilibili?q=${encodeURIComponent(query)}`)
    const result = data.result

    if (!result || result.length === 0) {
      throw ' Maaf, tidak ada hasil yang ditemukan!'
    }

    const vid = result[Math.floor(Math.random() * result.length)]

    const caption = `
🎬 *${vid.title}*
👤 *Creator:* ${vid.creator.name}
🔗 *Profile:* ${vid.creator.link}
👁️ *Views:* ${vid.views}
⏳ *Duration:* ${vid.duration}
📺 *Tonton:* ${vid.link}
    `.trim()

    await conn.sendMessage(m.chat, {
      image: { url: vid.imageUrl },
      caption: caption,
      footer: 'Bilibili Search by Bot',
      buttons: [
        { buttonId: `${usedPrefix + command} ${query}`, buttonText: { displayText: '🔁 Cari Lagi' }, type: 1 },
        { buttonId: `.menu`, buttonText: { displayText: '📋 Menu' }, type: 1 }
      ]
    }, { quoted: m })

  } catch (e) {
    console.error(e)
    throw '❌ Terjadi kesalahan saat mengambil data!'
  }
}

handler.help = ['bilibilish <judul>']
handler.tags = ['anime']
handler.command = /^bilibilish$/i
handler.register = true

export default handler