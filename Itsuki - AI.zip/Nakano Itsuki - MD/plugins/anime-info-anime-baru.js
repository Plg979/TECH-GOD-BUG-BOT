import fetch from 'node-fetch';
 
let handler = async (m, { conn }) => { try { let res = await fetch('https://www.velyn.biz.id/api/search/animeLatest'); let json = await res.json(); if (!json.status || !json.latestAnime || json.latestAnime.length === 0) throw 'Gagal mengambil data atau data kosong';
 
let message = '*Anime Terbaru:*\n\n';
    for (let anime of json.latestAnime.slice(0, 10)) {
        message += `📺 *${anime.title}*\n`;
        message += `🎬 Episode: ${anime.episode}\n`;
        message += `📡 Tipe: ${anime.type}\n`;
        message += `🔗 Link: ${anime.url}\n\n`;
    }
 
    if (message.trim() === '*Anime Terbaru:*\n\n') throw 'Data anime tidak tersedia';
    conn.reply(m.chat, message, m);
} catch (e) {
    conn.reply(m.chat, `❌ Error  \nLogs error : ${e}`, m);
}
 
};
 
handler.tags = ['anime']; 
handler.help = ['animeterbaru']; 
handler.command = /^(animeterbaru)$/i;
 
export default handler;