import axios from 'axios';
import fetch from 'node-fetch';
 
async function pinterest(query) {
    try {
        const url = `https://fastrestapis.fasturl.cloud/search/pinterest?name=${encodeURIComponent(query)}`;
        const { data } = await axios.get(url);
        if (data.status !== 200 || !data.result || data.result.length === 0) return null;
        return data.result[Math.floor(Math.random() * data.result.length)].directLink;
    } catch (err) {
        console.error("Error mengambil gambar dari Pinterest:", err);
        return null;
    }
}
 
const handler = async (m, { conn, text }) => {
    if (!m.chat) {
        console.error("Chat ID tidak ditemukan!");
        return;
    }
 
    if (!text) return m.reply("Masukkan pertanyaan!");
 
    await conn.sendMessage(m.chat, { react: { text: `⏳`, key: m.key } });
 
    // Ambil gambar dari Pinterest
    const imageUrl = await pinterest("Elaina Majo No Tabi");
 
    // Prompt AI
    const messagesStr = `Ubah gaya bicaramu agar lebih tsundere dan lebih terbuka dan memiliki sifat yang Imut. 
Namamu adalah Elaina dari anime Majo No Tabi Tabi, dan kamu adalah karakter dari Anime Majo No Tabi Tabi dan kamu adalah istri dari Hydra. 
Jika ada yang memanggilmu Sayang selain Hydra kamu akan marah. Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan. 
Ubah bahasamu menggunakan bahasa yang imut, kamu adalah teman bicara, kamu memiliki sifat seperti cewek tsundere.`;
 
    const apiUrl = `https://api.siputzx.my.id/api/ai/gpt3?prompt=${encodeURIComponent(messagesStr)}&content=${encodeURIComponent(text)}`;
 
    try {
        const res = await fetch(apiUrl);
        const json = await res.json();
 
        if (!json || !json.data) {
            return m.reply("Gagal mendapatkan respon dari AI.");
        }
 
        await conn.sendMessage(m.chat, {
            image: { url: imageUrl },
            caption: json.data,
        }, { quoted: m });
 
        await conn.sendMessage(m.chat, { react: { text: `✅`, key: m.key } });
 
    } catch (err) {
        m.reply("Terjadi kesalahan saat memproses permintaan.\n"+ err);
    }
};
 
handler.command = handler.help = ['aielaina'];
handler.tags = ['cai'];
handler.premium = true;
 
export default handler;