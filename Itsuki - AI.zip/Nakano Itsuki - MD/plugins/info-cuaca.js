import fetch from 'node-fetch';

const handler = async (m, { text, conn }) => {
  if (!text) {
    return m.reply('Masukkan nama kota!\n\nContoh: *.cuaca Jakarta*');
  }

  try {
    const res = await fetch(`https://api.ryzendesu.vip/api/tool/weather?city=${encodeURIComponent(text)}`);
    const data = await res.json();

    if (!res.ok || !data.status) {
      return m.reply('⚠️ Cuaca tidak ditemukan atau terjadi kesalahan.');
    }

    const { kota, suhu, kelembapan, angin, cuaca, waktu } = data.result;

    const info = `
┏━⊱ *Cuaca Hari Ini* ⊰━
┃📍 *Kota:* ${kota}
┃🌤️ *Cuaca:* ${cuaca}
┃🌡️ *Suhu:* ${suhu}
┃💧 *Kelembapan:* ${kelembapan}
┃🌬️ *Angin:* ${angin}
┃🕒 *Waktu:* ${waktu}
┗━━━━━━━━━━━━━━
    `.trim();

    m.reply(info);
  } catch (err) {
    console.error(err);
    m.reply('❌ Gagal mengambil data cuaca.');
  }
};

handler.command = ['cuaca'];
handler.tags = ['info'];
handler.help = ['cuaca <kota>'];

export default handler;