import fs from 'fs'

let handler = async (m, { conn }) => {
	let owner = `_Owner Arona MD_
*Nama Owner : Fall*
*Kontak Owner : https://wa.me//6285813708397*

Silakan Pencet Link Kontak Owner Di Atas.
_Jangan Call Dan Spam Owner Yah, Terimakasih._`;
	await conn.sendMessage(m.chat, { image: { url: 'https://files.catbox.moe/ujw9b0.jpg' }, caption: owner }, m)
}
handler.help = ['owner']
handler.tags = ['owner']
handler.command = /^(owner)$/i;

export default handler;