import fs from 'fs'

let handler = async (m, { conn }) => {
	let tqto = `Thanks Too :
	
*• Thanks To •*
*- Allah SWT*
*- Orang tua*
*- Teman²*
*- Eni My Buppie 🌹*
*- Dan yang selalu mendukung*

*• Special Thanks To •*
*- (Penyedia API, Dll)*
*- Adiwajshing* 
*- Bochilgaming* 
*- Elaina* 
*- ShyoXD*
*- ShyoCannn*
*- FallXd*
*- Donatur*


*_Ditulis Ulang Oleh ShyoXD_*

*Thank For All*
Terimakasih atas kalian jika tidak ada kalian maka bot ini tidak akan berkembang....

`;
	await conn.sendMessage(m.chat, { image: { url: 'https://files.catbox.moe/416nwe.jpg' }, caption: tqto }, m)
	await conn.sendFile(m.chat, './media/inimenu.mp3', '', null, m, true)
}
handler.help = ['tqto']
handler.tags = ['info']
handler.command = /^(tqto)$/i;

export default handler;