import axios from 'axios'

let handler = async (m, { conn }) => {
  try {
    const { data: json } = await axios.get('https://api.vreden.my.id/api/meme')

    if (!json.status || !json.result) throw '❌ Gagal mengambil meme.'

    await conn.sendMessage(m.chat, {
      image: { url: json.result },
      caption: ' *Meme Random Kadang Absurd*😐😹'
    }, { quoted: m })

  } catch (e) {
    console.error(e)
    m.reply('❌ Terjadi kesalahan saat mengambil meme.')
  }
}

handler.help = ['meme2']
handler.tags = ['internet']
handler.command = /^meme2$/i

export default handler