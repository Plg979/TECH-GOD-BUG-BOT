import axios from 'axios';
import cheerio from 'cheerio';

const handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*Example :* ${usedPrefix + command} https://xbato.com/series/99300/can-we-become-family-official`;

  try {
    let data = await getSeriesDetail(text);
    if (!data) throw 'Gagal Dapetin Detail Nya';

    let caption = `${data.title}\n\n`;
    if (data.aliases.length) caption += `Aliases : ${data.aliases.join(', ')}\n`;
    caption += `Authors : ${data.authors.join(', ')}\n`;
    caption += `Artists : ${data.artists.join(', ')}\n`;
    caption += `Genres : ${data.genres.join(', ')}\n`;
    caption += `Language : ${data.language}\n`;
    caption += `Translated : ${data.translated}\n`;
    caption += `Status : ${data.status}\n`;
    caption += `Upload Status : ${data.uploadStatus}\n`;
    caption += `Year : ${data.year}\n\n`;
    caption += `Summary :\n${data.summary}\n\n`;
    caption += `Total Chapters : ${data.chapters.length}\n\n`;

    if (data.chapters.length) {
      caption += 'Latest Chapters :\n' +
        data.chapters.slice(0, 5).map((v, i) =>
          `${i + 1}. ${v.title}\n   Upload Date : ${v.uploadDate}\n   Views : ${v.views}\n   Link : ${v.url}`
        ).join('\n\n') + '\n\n';
      if (data.chapters.length > 5)
        caption += `...and ${data.chapters.length - 5} more chapters`;
    }

    await conn.sendMessage(m.chat, {
      image: { url: data.thumbnail },
      caption
    }, { quoted: m });

  } catch (e) {
    m.reply('Error : ' + e.message);
  }
};

async function getSeriesDetail(url) {
  try {
    const base = 'https://xbato.com';
    let { data } = await axios.get(url);
    let $ = cheerio.load(data), c = $('.container-max-width-xl');

    const parseList = sel => c.find(sel).next().find('a').map((i, el) => $(el).text().trim()).get();
    const getText = sel => c.find(sel).next().text().trim();

    return {
      title: c.find('.title-set h3.item-title a').text().trim(),
      aliases: c.find('.alias-set').text().trim().split('/').map(a => a.trim()).filter(Boolean),
      thumbnail: c.find('.attr-cover img').attr('src'),
      authors: parseList('.attr-item b:contains("Authors:")'),
      artists: parseList('.attr-item b:contains("Artists:")'),
      genres: c.find('.attr-item b:contains("Genres:")').next().children().map((i, el) => $(el).text().trim()).get(),
      language: getText('.attr-item b:contains("Original language:")'),
      translated: getText('.attr-item b:contains("Translated language:")'),
      status: getText('.attr-item b:contains("Original work:")'),
      uploadStatus: getText('.attr-item b:contains("Upload status:")'),
      year: getText('.attr-item b:contains("Year of Release:")'),
      summary: c.find('.limit-html').text().trim(),
      chapters: $('.item').map((i, el) => {
        let ch = $(el);
        return {
          title: ch.find('a.visited.chapt b').text().trim(),
          url: base + ch.find('a.visited.chapt').attr('href'),
          views: ch.find('.extra span.ps-3 i').map((i, el) => $(el).text().trim()).get().join(' '),
          uploadDate: ch.find('.extra i.ps-3').text().trim()
        };
      }).get()
    };
  } catch (e) {
    console.error('Skill Issue:', e.message);
    return null;
  }
}

handler.help = ['xbato '];
handler.command = ['xbato'];
handler.tags = ['weebs'];

export default handler;

handler.help = ['xbato '];
handler.command = ['xbato'];
handler.tags = ['internet'];

export default handler;