let handler = async (m, {
    conn,
    usedPrefix,
    command,
    text
}) => {
    conn.reply(m.chat, `_*Yahaha goblok banget*_ 
bukan allmenu tapi *menulist all :p*`, m);
}
handler.help = ['allmenu']
handler.tags = ['main']
handler.command = /^(allmenu)$/i
handler.owner = false
handler.mods = false
handler.premium = false
handler.group = false
handler.private = false

handler.admin = false
handler.botAdmin = false

handler.fail = null

export default handler