import moment from 'moment-timezone'
import PhoneNumber from 'awesome-phonenumber'
import fs from 'fs'
import fetch from 'node-fetch'
const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = (await import('@adiwajshing/baileys')).default;
let handler = async (m, { conn }) => {
    const pp = await conn.profilePictureUrl(m.sender, 'image').catch(() => "https://telegra.ph/file/1ecdb5a0aee62ef17d7fc.jpg");
    const { age, money, limit, level, registered, premium } = global.db.data.users[m.sender] || {};
    const totalFeatures = Object.values(global.plugins).filter(v => v.help && v.tags).length;
    const userAge = age > 0 ? age : 'BELUM DAFTAR ࿐';
    const totalRegistered = Object.keys(global.db.data.users || {}).length;
    const userData = global.db.data.users[m.sender] || {};
    const userStatus = m.sender.split('@')[0] === global.config.owner
      ? 'Developer'
      : (userData.premiumTime > 0 ? 'Premium User' : 'Free User');
    const premiumStatus = userData.premiumTime > 0 ? 'Yes' : 'No';
    const isPublic = true;
    const name = registered ? userData.name : conn.getName(m.sender);
    const blockList = await conn.fetchBlocklist();
    const totalBlocked = blockList.length || 0;
    const bannedUsers = Object.entries(global.db.data.users || {}).filter(([_, user]) => user.banned).length;
    const activeUsers = Object.keys(global.db.data.users || {}).filter(v => global.db.data.users[v]?.commandTotal !== undefined);
    const commandToday = activeUsers.reduce((sum, user) => sum + (global.db.data.users[user]?.command || 0), 0);
    const ratings = Object.values(global.db.data.bots.rating || {}).map(v => v.rate || 0);
    const averageRating = ratings.length > 0 ? (ratings.reduce((sum, rate) => sum + rate, 0) / ratings.length).toFixed(2) : 0;
    
let menu =  `Hai Kak ${name}, Saya Nakano itsuki yang bisa membantu kalian, saya memiliki fitur AI, Downloader, dan lainnya. Bot ini masih dalam masa pengembangan yaa.
    
┌  • Bot - Info
│ Name : Nakano Itsuki
│ Mode : ${isPublic ? "Public" : "Self"}
│ User Banned : ${bannedUsers} banned
│ User Blocked : ${totalBlocked} block
│ Total Premium : ${Object.values(global.db.data.users || {}).filter(u => u.premiumTime > 0).length}
│ Command Today : ${commandToday}
│ Rating Bot : ${averageRating}/5.00 (${ratings.length} Users)
└──······`
await loading(m, conn)

await conn.sendMessage(m.chat, {
    image: { url: 'https://files.catbox.moe/5lin2a.jpg' },
    gifPlayback: true,
    caption: menu,
        buttons: [{
                buttonId: '.menulis allt',
                buttonText: {
                    displayText: 'Menu list'
                },
                type: 1
            },

            {
                buttonId: '.owner',
                buttonText: {
                    displayText: 'Creator owner'
                },
                type: 4
            }
        ],
    headerType: 1,
    viewOnce: true
  }, { quoted: m })

conn.sendFile(m.chat, 'https://files.catbox.moe/1b4y9q.opus', null, null, m, true, { ptt: true })
}

handler.command = /^(menu|help)$/i;
handler.register = true
export default handler;

function ucapan() {
    const time = moment.tz("jakarta/lampung").format("HH")
    let res = "Selamat Dini Hari ☀️"
    if (time >= 4) {
        res = "Selamat Pagi 🌄"
    }
    if (time >= 10) {
        res = "Selamat Siang ☀️"
    }
    if (time >= 15) {
        res = "Selamat Sore 🌇"
    }
    if (time >= 18) {
        res = "Selamat Malam 🌙"
    }
    return res
}